//
//  MovieDetail.swift
//  Movie
//
//  Created by Te Zar Hlaing on 2/11/17.
//  Copyright © 2017 ShopBack. All rights reserved.
//

import Foundation
class MovieDetail{
    var id: NSNumber
    var backdrop_path: String
    var genres: [Any]
    var original_title: String
    var original_language :String
    var overview: String
    var poster_path : String
    var release_date: String
    var runtime : Int
    
    init(obj: AnyObject) {
        self.id = obj["id"] as! NSNumber
        self.backdrop_path = obj["backdrop_path"] as? String ?? "-"
        self.genres = obj["genres"] as! [Any]
        self.original_title = obj["original_title"] as? String ?? "-"
        self.original_language = obj ["original_language"] as? String ?? "-"
        self.overview = obj["overview"] as? String ?? "-"
        self.poster_path = obj["poster_path"] as? String ?? "-"
        self.release_date = obj["release_date"] as? String ?? "-"
        self.runtime = obj["runtime"] as! Int

    }
    

}
