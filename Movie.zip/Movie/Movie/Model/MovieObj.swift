//
//  MovieObj.swift
//  Movie
//
//  Created by IT Mobile Mac 01 on 10/2/17.
//  Copyright © 2017 ShopBack. All rights reserved.
//

import UIKit

struct MovieObj {
    
    var poster_path : String
    var adult: Bool
    var overview: String
    var release_date: String
    var genre_ids: [Any]
    var id: NSNumber
    var original_title: String
   // let original_language: String
    var title: String
    var backdrop_path: String
    var popularity: Double
    var vote_count: Int
    var video: Bool
    var vote_average: NSNumber
    

    
     init(obj: AnyObject) {

        self.poster_path = obj["poster_path"] as? String ?? "-"
        self.adult = obj["adult"] as! Bool
        self.overview = obj["overview"] as? String ?? "-"
        self.release_date = obj["release_date"] as? String ?? "-"
        self.genre_ids = obj["genre_ids"] as! [Any]
        self.id = obj["id"] as! NSNumber
        self.original_title = obj["original_title"] as? String ?? "-"
       // self.original_language = obj ["original_language"] as!
        self.title = obj["title"] as? String ?? "-"
        self.backdrop_path = obj["backdrop_path"] as? String ?? "-"
        self.popularity = obj ["popularity"] as! Double
        self.vote_count = obj["vote_count"] as! Int
        self.video = obj["video"] as! Bool
        self.vote_average = obj["video"] as! NSNumber

        
    }

    

}
