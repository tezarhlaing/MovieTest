//
//  ConnectionManager.swift
//  Movie
//
//  Created by IT Mobile Mac 01 on 10/2/17.
//  Copyright © 2017 ShopBack. All rights reserved.
//

import Foundation
class ConnectionManager{
     let baseURL:String = "http://api.themoviedb.org/3/"
    //http://api.themoviedb.org/3/movie/328111?api_key=328c283cd27bd1877d9
    
    //http://api.themoviedb.org/3/discover/324552?api_key=a23394d42c95a1a0493cfdc099415b48
    //http://api.themoviedb.org/3/movie/324552?api_key=a23394d42c95a1a0493cfdc099415b48
    func getMovieList(requestDictParam : Dictionary<String, Any>,funtionName: String,callBackView:HomeViewController)
     {
        
        let manager = AFHTTPSessionManager()
        var url :String = baseURL
        url.append(funtionName)
        var movieList = [MovieObj] ()

        manager.get(url, parameters: requestDictParam,
                    progress: nil,
                    success:
            {
                (operation, responseObject) in
                let jsonResult = responseObject as? [String: AnyObject]
                let results = jsonResult?["results"] as! [AnyObject]
                for result in results{
                    let movieObj = MovieObj.init(obj: result)
        
                    movieList.append(movieObj)
                }
                DispatchQueue.main.async {
                    if movieList.count != 0 {
                       
                        callBackView.movieList.append(contentsOf: movieList)
                        callBackView.tableView.reloadData()

                    }
                }

                
        },
        failure: {
                (operation, error) in
                print("Error: " + error.localizedDescription)
        })
    }
    
    func getMovieDetail(requestDictParam:Dictionary<String, Any>,funtionName:String,callBackView:DetailViewController) {
        let manager = AFHTTPSessionManager()
        var url :String = baseURL
        url.append(funtionName)
        manager.get(url, parameters: requestDictParam,
                    progress: nil,
                    success:
            {
                (operation, responseObject) in
                let jsonResult = responseObject as? AnyObject
                let movieObj = MovieDetail.init(obj: jsonResult!)
                DispatchQueue.main.async {
                    callBackView.setData(movie: movieObj)
                }
                
                
        },
        failure: {
                        (operation, error) in
                        print("Error: " + error.localizedDescription)
        })

    }
    
}
