//
//  ViewController.swift
//  Movie
//
//  Created by IT Mobile Mac 01 on 9/2/17.
//  Copyright © 2017 ShopBack. All rights reserved.
//

import UIKit

class HomeViewController: UITableViewController,MenuTransitionManagerDelegate {

    let menuTransitionManager = MenuTransitionManager()
    let apiKey : String = "a23394d42c95a1a0493cfdc099415b48"
    var movieList : [MovieObj] = []
    var relDate : String = ""
    var page : Int = 1
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.title = "Home"
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let currentDateTime = Date()
        relDate = dateFormatter.string(from: currentDateTime)
        self.getData(releaseDate: relDate, page: page)
        
       // print("Movie",movieList)
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func dismiss() {
        self.dismiss(animated: true, completion: nil)
    }
    
    func getData(releaseDate : String, page : Int) {
        var requestDict = [String: Any]()
        requestDict ["api_key"] = apiKey
        requestDict ["primary_release_date.lte"] = "2017-02-09"
        requestDict ["sort_by"] = "release_date.desc"
        requestDict ["page"] = 1
        let connection = ConnectionManager()
        connection.getMovieList(requestDictParam: requestDict,funtionName: "discover/movie?",callBackView: self)
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.movieList.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! MovieListCell
        if indexPath.row == movieList.count-1 {
            page = page + 1
            self.getData(releaseDate: self.relDate, page: page)
        }
        else{
            let movie = movieList[indexPath.item]
            print("MovieObj",movie)
            
            cell.setData(title: movie.title, postURL: movie.poster_path,overView: movie.overview,at: indexPath.row)

        }
        
        return cell
    }
   
    
    func tableView(_tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "MenuTableViewController"
        {
            let menuTableViewController = segue.destination as! MenuTableViewController
            menuTableViewController.currentItem = self.title!
            menuTableViewController.transitioningDelegate = menuTransitionManager
            menuTransitionManager.delegate = self

        }
        else{
            
            let detailViewController = segue.destination as! DetailViewController
            let btn = sender as! UIButton
            detailViewController.movieId = self.movieList[btn.tag].id as Int!

        }
    }

    
}


