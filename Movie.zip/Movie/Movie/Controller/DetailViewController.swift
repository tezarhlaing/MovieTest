//
//  DetailViewController.swift
//  Movie
//
//  Created by Te Zar Hlaing on 2/11/17.
//  Copyright © 2017 ShopBack. All rights reserved.
//

import Foundation
class DetailViewController : UIViewController{
    let apiKey : String = "a23394d42c95a1a0493cfdc099415b48"

    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var imgMovie: UIImageView!
    @IBOutlet weak var movieData: UIView!
    @IBOutlet weak var txtOverview: UITextView!
    var movieId : Int!
    
    let imgBaseURL : String = "http://image.tmdb.org/t/p/w500/"
    var detailMovie : MovieDetail?
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        var strID = "movie/"
        strID.append(String(movieId))
        strID.append("?")
        print("ID",strID)
        self.getData(function:strID)
    }
       override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Disp
    }
    
    func getData(function:String) {
        var requestDict = [String: Any]()
        requestDict ["api_key"] = apiKey
        let connection = ConnectionManager()
        connection.getMovieDetail(requestDictParam: requestDict,funtionName: function, callBackView: self)

    }
    func setData(movie: MovieDetail) {
        self.lblTitle.text = movie.original_title
        self.txtOverview.text = movie.overview
        let strURL = imgBaseURL + movie.poster_path
        let imgURL = Foundation.URL(string: strURL)
        self.imgMovie.setImageWithUrl(imgURL!);
        
    }
    


}
