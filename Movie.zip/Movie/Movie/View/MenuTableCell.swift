//
//  MenuTableCell.swift
//  Movie
//
//  Created by Te Zar Hlaing on 2/11/17.
//  Copyright © 2017 ShopBack. All rights reserved.
//

import Foundation
class MenutableCell : UITableViewCell {
    
    @IBOutlet weak var titleLabel:UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
