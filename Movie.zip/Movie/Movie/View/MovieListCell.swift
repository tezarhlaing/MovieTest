//
//  MovieListCell.swift
//  Movie
//
//  Created by IT Mobile Mac 01 on 10/2/17.
//  Copyright © 2017 ShopBack. All rights reserved.
//

import Foundation
class MovieListCell: UITableViewCell {
    @IBOutlet weak var backImg: UIImageView!
    @IBOutlet weak var movieTitle: UILabel!
    @IBOutlet weak var btnMoreInfo: UIButton!
    @IBOutlet weak var textOverView: UITextView!
    let imgBaseURL : String = "http://image.tmdb.org/t/p/w500/"

    func setData(title:String,postURL:String,overView:String,at index:Int) {
        movieTitle.text = title
        self.textOverView.text = overView
        let strURL = imgBaseURL + postURL
        let imgURL = Foundation.URL(string: strURL)
        self.backImg.setImageWithUrl(imgURL!);
        
        self.btnMoreInfo?.tag = index
    }
    
}
