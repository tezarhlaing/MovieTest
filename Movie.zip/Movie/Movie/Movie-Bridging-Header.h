//
//  Movie-Bridging-Header.h
//  Movie
//
//  Created by IT Mobile Mac 01 on 9/2/17.
//  Copyright © 2017 ShopBack. All rights reserved.
//

#ifndef Movie_Bridging_Header_h
#define Movie_Bridging_Header_h

#import "AFNetworking.h"

#endif /* Movie_Bridging_Header_h */
